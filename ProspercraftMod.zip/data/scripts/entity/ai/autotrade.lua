-- (c)2017 Splutty
-- Free to distribute, adjust, recode, mangle, feed to your dog, just leave this top line.

package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/entity/?.lua"

require("ai/dock")
require("randomext")
require("utility")
require("goods")

local DockAI = require ("ai/dock")

local VERSION = "v0.9.2"
local ME = "data/scripts/entity/ai/autotrade.lua"
local factory = "data/scripts/entity/merchants/factory.lua"


-- This is the list of functions that will be executed in order for every route that is given to this ship
--haulGoodsSteps = {
--	[1] = haulGoodsGetRoute,
--	[2] = haulGoodsMoveToSeller,
--	[3] = haulGoodsBuyGoods,
--	[4] = haulGoodsMoveToBuyer,
--	[5] = haulGoodsSellGoods,
--}
local haulGoodsStage

-- Contains all goods for sector on dispatcher only
-- (good = {{from}, {to}, amount})
local haulGoodsList
-- A simple list of the goods actually available for hauling
local haulGoods

-- Dispatcher object
local haulGoodsDispatcher

-- Current route for hauling goods (from_station, to_station, good [, amount])
local haulGoodsRoute

local isInit

function restore(values)
    haulGoodsStage = values.haulGoodsStage
    local haulSaveList = values.haulGoodsList
    haulGoods = values.haulGoods
    haulGoodsDispatcher = Uuid(values.haulGoodsDispatcher)
    if (values.haulGoodsRoute ~= nil) then
        haulGoodsRoute = { Uuid(values.haulGoodsRoute[1]), Uuid(values.haulGoodsRoute[2]), values.haulGoodsRoute[3], values.haulGoodsRoute[4] }
    end
	if (haulSaveList ~= nil) then	
		haulGoodsList = {}
		for good, route in pairs(haulSaveList)
		do
			haulGoodsList[good] = { from = {}, to = {}, amount = route["amount"] }
			for _, from in pairs(route["from"]) do
				print(from)
				table.insert(haulGoodsList[good]["from"], Uuid(from))
			end
			for _, to in pairs(route["to"]) do
				table.insert(haulGoodsList[good]["to"], Uuid(to))
			end

		end
	end
	DockAI.restore(values)

end

function secure()
    local haulRoute
    if haulGoodsRoute ~= nil and #haulGoodsRoute == 4 then
        haulRoute = { haulGoodsRoute[1].string, haulGoodsRoute[2].string, haulGoodsRoute[3], haulGoodsRoute[4] }
    end
    local haulSaveList
	if (haulGoodsList ~= nil) then
		haulSaveList = {}
		for good, route in pairs(haulGoodsList)
		do
			if (route ~= nil) then
				haulSaveList[good] = { from = {}, to = {}, amount = route["amount"] }
				for _, from in pairs(route["from"]) do
					table.insert(haulSaveList[good]["from"], from.string)
				end
				for _, to in pairs(route["to"]) do
					table.insert(haulSaveList[good]["to"], to.string)
				end

			end

		end
	end
    local values =     {
        haulGoodsStage = haulGoodsStage,
        haulGoodsList = haulSaveList,
        haulGoods = haulGoods,
        haulGoodsDispatcher = haulGoodsDispatcher.string,
        haulGoodsRoute = haulRoute
		
    }
	DockAI.secure(values)
	return values
end



function isHaulGoodsHauler()
    return true
end
function isHaulGoodsDispatcher()
    return (type(haulGoodsList) == "table")
end

function haulGoodsStatus()
    local ship = Entity()
    local returnstring = ship.name .. " is "

    if (not haulGoodsStage or haulGoodsStage == 0 or not haulGoodsRoute or not next(haulGoodsRoute))
    then
        returnstring = returnstring .. "doing nothing."
    elseif (haulGoodsStage == 1) then
        returnstring = returnstring .. "attempting to acquire a trade route."
    elseif (haulGoodsStage == 2) then
        returnstring = returnstring .. "moving to station to buy " .. haulGoodsRoute[3]
    elseif (haulGoodsStage == 3) then
        returnstring = returnstring .. "buying goods from station."
    elseif (haulGoodsStage == 4) then
        returnstring = returnstring .. "moving to station to sell " .. haulGoodsRoute[3]
    elseif (haulGoodsStage == 5) then
        returnstring = returnstring .. "selling goods to station."
    end

    return returnstring
end

-- Comment at the "return" to enable debugging
function debug_msg(message)
    return 
    local name = Entity().name

    if (not name) then
        name = "Unknown"
    end

    print(VERSION .. " " .. os.date() .. " (" .. name .. ") " .. ME .. ": " .. message)
end

function getUpdateInterval()
    return 5
end

function initialize()
    if (onServer())
    then
		isInit = false;
    end
end

-- Find a dispatcher, or if one doesn't exist yet, make myself the dispatcher and build a goods list
function findDispatcher()
    local ship = Entity()
    local sector = Sector()
    local ships = { sector:getEntitiesByType(EntityType.Ship) }
    local dispatcher

    -- Check all ships in this sector
    for _, dispatcher in pairs(ships) do
        if (dispatcher:hasScript(ME))
        then
            local retval, isDispatcher = dispatcher:invokeFunction(ME, "isHaulGoodsDispatcher")

            if (retval == 0 and isDispatcher)
            then
                -- Found a dispatcher! Register it and try to get a goods route
                debug_msg("Found a dispatcher. (" .. dispatcher.name .. ")")
                haulGoodsDispatcher = dispatcher.index
                -- Ignore retval since it doesn't matter
                haulGoodsRoute = { Entity(haulGoodsDispatcher):invokeFunction(ME, "requestGoodsRoute", ship) }
                retval = table.remove(haulGoodsRoute, 1)
                return
            end
        end
    end

    -- No dispatcher found, so I'm the current dispatcher
    debug_msg("Created the dispatcher.")
    haulGoodsDispatcher = ship.index
    buildGoodsList(ship)
    haulGoodsRoute = { requestGoodsRoute(ship) }
end

function determineStationScript(station)
    -- Possible station types to buy/sell stuff
    local stationscripts = {
        "data/scripts/entity/merchants/factory.lua",
        "data/scripts/entity/merchants/basefactory.lua",
        "data/scripts/entity/merchants/lowfactory.lua",
        "data/scripts/entity/merchants/midfactory.lua",
        "data/scripts/entity/merchants/highfactory.lua",
        "data/scripts/entity/merchants/consumer.lua",
        "data/scripts/entity/merchants/tradingpost.lua"
    }
    local script
    local stationscript

    for _, script in pairs(stationscripts)
    do
        if (station:hasScript(script))
        then
            -- Don't return anything yet, want to see if there are stations that have multiple scripts
            --debug_msg("Station " .. station.name .. " (" .. station.title .. ") has script " .. script)
            stationscript = script
        end
    end

    if (not stationscript)
    then
        -- Try to figure out what scripts it does have
        --debug_msg("Station " .. station.name .. " (" .. station.title .. ") has no script. Scripts available:")
        --printTable(station:getScripts())
    end

    -- Can be nil if station doesn't have any of our needed scripts
    return stationscript
end

-- Make a goods list matching buyers and sellers
function buildGoodsList(ship)
    local sector = Sector()
    local stations = { sector:getEntitiesByType(EntityType.Station) }
    local station
    local stationscript
    local retval

    local soldgoods
    local boughtgoods
    local good

    haulGoodsList = {}
    haulGoods = {}

    for _, station in pairs(stations)
    do
        -- Determine whether station actually has docks
        local pos, dir = station:getDockingPositions()
        -- Determine stationscript to call, can be nil if there isn't a useful script for us
        stationscript = determineStationScript(station)

        if (pos and stationscript)
        then
            -- Station has docks, continue
            soldgoods = { station:invokeFunction(stationscript, "getSoldGoods") }

            retval = table.remove(soldgoods, 1)

            if (retval == 0 and next(soldgoods))
            then
                for _, good in pairs(soldgoods)
                do
                    -- Don't bother doing anything if there isn't anything to actually sell
                    local numGoods

                    retval, numGoods = station:invokeFunction(stationscript, "getNumGoods", good)
                    --				debug_msg(station.name .. " is selling " .. numGoods .. " " .. good)

                    if (retval == 0 and numGoods > 0)
                    then
                        if (haulGoodsList[good]) -- Already initialized?
                        then
                            table.insert(haulGoodsList[good]["from"], station.index)
                        else -- Initialize good
                            haulGoodsList[good] = { from = { station.index }, to = {}, amount = numGoods }
                        end
                    end
                end
            end -- Valid soldgoods

            boughtgoods = { station:invokeFunction(stationscript, "getBoughtGoods") }

            retval = table.remove(boughtgoods, 1)

            if (retval == 0 and next(boughtgoods))
            then
                for _, good in pairs(boughtgoods)
                do
                    -- Don't bother if the station's already full
                    local available, maxgoods
                    retval, available, maxgoods = station:invokeFunction(stationscript, "getStock", good)

                    --				debug_msg(station.name .. " is buying " .. good .. " available/max " .. available .. "/" .. maxgoods)

                    if (retval == 0 and (maxgoods - available) > 0)
                    then
                        if (haulGoodsList[good])
                        then
                            table.insert(haulGoodsList[good]["to"], station.index)
                        else
                            haulGoodsList[good] = { from = {}, to = { station.index }, amount = 0 }
                        end
                    end
                end
            end -- Valid boughtgoods
        end -- Dockcheck
    end -- Station loop

    local route
    -- Delete all the entries that don't have both a source and destination
    for good, route in pairs(haulGoodsList)
    do
        if (not next(route["to"]) or not next(route["from"]))
        then
            haulGoodsList[good] = nil
        else
            table.insert(haulGoods, good)
        end
    end

end

function requestGoodsRoute(ship)
    local retval
    local good
    local route
    local stationscript

    local free = ship.freeCargoSpace

    -- If there is nothing left, return nothing to force a rebuild of the list
    if (not next(haulGoodsList))
    then
        return
    end

    -- This is relatively random
    good = haulGoods[1]
    route = haulGoodsList[good]
    if (not route)
    then
        -- None of this good left
        table.remove(haulGoods, 1)
        if (#haulGoods > 0)
        then
            -- Reiterate for next good
            return requestGoodsRoute(ship)
        else -- Totally out of goods
            return
        end
    end

    local fromStations = route["from"]
    local toStations = route["to"]
    local amount = 0
    local stock = { fromstock = 0, tostock = 0, fromindex = 1, toindex = 1, fromprice = 0, toprice = 0 }

    local fromIndex, fromStation
    local numGoods, priceGoods

    -- Find the highest stock amount to buy
    for fromIndex, fromStation in pairs(fromStations)
    do
        stationscript = determineStationScript(Entity(fromStation))
        retval, numGoods = Entity(fromStation):invokeFunction(stationscript, "getNumGoods", good)
        if (retval == 0 and numGoods >= stock["fromstock"])
        then
            stock["fromstock"] = numGoods
            stock["fromindex"] = fromIndex
            retval, priceGoods = Entity(fromStation):invokeFunction(stationscript, "getSellPrice", good, ship.factionIndex)
            stock["fromprice"] = priceGoods
        end
    end

    local toIndex, toStation
    local neededGoods

    -- Find the most needed stock amount to sell
    for toIndex, toStation in pairs(toStations)
    do
        local available, maxgoods

        stationscript = determineStationScript(Entity(toStation))
        retval, available, maxgoods = Entity(toStation):invokeFunction(stationscript, "getStock", good)
        if (retval == 0)
        then
            neededGoods = maxgoods - available
            if (neededGoods >= stock["tostock"])
            then
                stock["tostock"] = neededGoods
                stock["toindex"] = toIndex
                retval, priceGoods = Entity(toStation):invokeFunction(stationscript, "getBuyPrice", good, ship.factionIndex)
                stock["toprice"] = priceGoods
            end
        end
    end

    -- Remove this trading route from our global list
    if (#fromStations == 1 or #toStations == 1)
    then
        -- Length comparison always faster than removing members from lists
        from = fromStations[stock["fromindex"]]
        to = toStations[stock["toindex"]]
        haulGoodsList[good] = nil
    else
        from = table.remove(haulGoodsList[good]["from"], stock["fromindex"])
        to = table.remove(haulGoodsList[good]["to"], stock["toindex"])
    end

    if (stock["fromprice"] > stock["toprice"])
    then
         --Would run a loss (this takes into account 0 prices for player factories)
        debug_msg("Route is not profitable for buying at " .. stock["fromprice"] .. " and selling at " .. stock["toprice"])
        return
    end

    local maxcargo = math.floor(free / getGoodAttribute(good, "size"))

    amount = math.min(stock["fromstock"], stock["tostock"], maxcargo)

    return from, to, good, amount
end

-- Check validity of stored route
function checkGoodsRoute()
    if (not haulGoodsRoute or not next(haulGoodsRoute))
    then
        -- No route at this point means something is wrong, reset to getting one
        print "Assert: Trading route reset, no viable trading route found in object"
        haulGoodsStage = 1
        return false
    end

    return true
end

function haulGoodsGetRoute()
    if (not haulGoodsRoute or not next(haulGoodsRoute))
    then
        -- No route for me! Get a new one. findDispatcher() should fill my haulGoodsRoute
        findDispatcher()
        if (not checkGoodsRoute()) then
            return false
        end
    end

    if (not next(haulGoodsRoute))
    then
        -- Route is empty, probably need to repopulate the list
        return false
    end

    return true -- Got a route, now to execute it.
end

function haulGoodsMoveToSeller(ship)
    if (not checkGoodsRoute()) then
        return false
    end
    local pos, dir = Entity(haulGoodsRoute[1]):getDockingPositions()
    if (pos ~= nil and dir ~= nil) then
		--print("docking position defined")
        return DockAI.flyToDock(ship, Entity(haulGoodsRoute[1]))
    else
		--print("docking position UNdefined")
        dir = station.up;
        pos = station.size;
        -- Fly to the dock, returns true once it's there
        local station = Entity(haulGoodsRoute[1])
        local target = station.position:transformCoord(pos + dir * 250)
        ShipAI(ship.index):setFly(target, 0)
        ShipAI(ship.index):setPassive()
        return true;
    end
end

function haulGoodsBuyGoods(ship)
    if (not checkGoodsRoute()) then
        return false
    end

	-- Buy the amount of goods for this route
	local station = Entity(haulGoodsRoute[1])
	local good = haulGoodsRoute[3]
	local amount = haulGoodsRoute[4]
	local retval
	local stationscript
	if (amount > ship:getCargoAmount(good)) then
		-- This has no useful return values :(
		stationscript = determineStationScript(station)
		station:invokeFunction(stationscript, "sellToShip", ship.index, good, amount, true)

		-- Check if the transfer went correctly
		cargoAmount = ship:getCargoAmount(good)
		debug_msg(cargoAmount .. " " .. good .. " in cargohold after attempting to buy " .. amount)
	end
    return DockAI.flyAwayFromDock(ship, station)
end

function haulGoodsMoveToBuyer(ship)
    if (not checkGoodsRoute()) then
        return false
    end
    local pos, dir = Entity(haulGoodsRoute[2]):getDockingPositions()
    if (pos ~= nil and dir ~= nil) then
		--print("docking position defined")
        return DockAI.flyToDock(ship, Entity(haulGoodsRoute[2]))
    else
		--print("docking position UNdefined")
        dir = station.up;
        pos = station.size;
        -- Fly to the dock, returns true once it's there
        local station = Entity(haulGoodsRoute[2])
        local target = station.position:transformCoord(pos + dir * 250)
        ShipAI(ship.index):setFly(target, 0)
        ShipAI(ship.index):setPassive()
        return true;
    end
end

function haulGoodsSellGoods(ship)
    if (not checkGoodsRoute()) then
        return false
    end

    -- Sell the amount of goods for this route
    local station = Entity(haulGoodsRoute[2])
    local good = haulGoodsRoute[3]
    local amount = haulGoodsRoute[4]
    local retval
    local stationscript

    local cargoAmount = ship:getCargoAmount(good)
	if (cargoAmount > 0) then 
		if (cargoAmount > amount)
		then
			-- Try to sell everything in cargohold
			amount = cargoAmount
		end

		-- This has no useful return values :(
		stationscript = determineStationScript(station)
		station:invokeFunction(stationscript, "buyFromShip", ship.index, good, amount, true)

		debug_msg("Sold " .. (cargoAmount - ship:getCargoAmount(good)) .. " " .. good)
	end
    return DockAI.flyAwayFromDock(ship, station)
end

-- this function will be executed every frame on the server only
function updateServer(timeStep)
    if (haulGoodsDispatcher == nil) then
        findDispatcher()
    end

    haulGoodsStage = haulGoodsStage or 1 -- Initialize if nil
    --debug_msg("haulGoods Stage " .. haulGoodsStage)
    local ship = Entity()
	if (not isInit) then
		debug_msg(haulGoodsStatus())
		isInit = true
	end
    if (haulGoodsStage == 1)
    then
        if (haulGoodsGetRoute())
        then
            debug_msg("haulGoodsGetRoute (Stage 1) finished. Starting to transport " .. haulGoodsRoute[4] .. " " .. haulGoodsRoute[3] .. " from " .. Entity(haulGoodsRoute[1]).name .. " to " .. Entity(haulGoodsRoute[2]).name)
            haulGoodsStage = haulGoodsStage + 1
            return
        elseif (not haulGoodsRoute or not next(haulGoodsRoute))
        then
            -- Received an empty list. If I'm the dispatcher, rebuild the list.
            debug_msg("Empty list received, no queue left.")
            if (Entity(haulGoodsDispatcher).name == ship.name)
            then
                debug_msg("Building new list.")
                buildGoodsList(ship)
            else -- If I'm not the dispatcher, find the dispatcher, and if there isn't one, make me the dispatcher
                findDispatcher()
            end
            return
        end
    end

    if (haulGoodsStage == 2)
    then
        if (haulGoodsMoveToSeller(ship))
        then
            debug_msg("haulGoodsMoveToSeller (Stage 2) finished")
            dockStage = 0
            haulGoodsStage = haulGoodsStage + 1
            return
        else
            return
        end
    end

    if (haulGoodsStage == 3)
    then
        if (haulGoodsBuyGoods(ship))
        then
			DockAI.usedDock = nil
			DockAI.dockStage = 0
			DockAI.undockStage = 0
            debug_msg("haulGoodsBuyGoods (Stage 3) finished")
            haulGoodsStage = haulGoodsStage + 1
            return
        else
            return
        end
    end

    if (haulGoodsStage == 4)
    then
        if (haulGoodsMoveToBuyer(ship))
        then
            debug_msg("haulGoodsMoveToBuyer (Stage 4) finished")
            dockStage = 0
            haulGoodsStage = haulGoodsStage + 1
            return
        else
            return
        end
    end

    if (haulGoodsStage == 5)
    then
        if (haulGoodsSellGoods(ship))
        then
			DockAI.usedDock = nil
			DockAI.dockStage = 0
			DockAI.undockStage = 0
            debug_msg("haulGoodsSellGoods (Stage 5) finished")
            haulGoodsStage = 1
            haulGoodsRoute = {}
            return
        else
            return
        end
    end

end


