if (not onServer()) then return end
	
package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/entity/?.lua"

require ("utility")

local haulscript = "data/scripts/entity/ai/autotrade.lua"

function haulGoodsCmdSendError(player, errorMessage, help)
	player:sendChatMessage("HaulGoods", 1, errorMessage)
	player:sendChatMessage("HaulGoods", 0, errorMessage .. help)
end

function haulGoodsCheckValidShip(player, ship)
	-- Check if the ship belongs to me (not sure how to do this yet :)
	print (ship.factionIndex)
	
	-- Check if the ship has a captain (craftorders can't take a ship object)
	local captains = ship:getCrewMembers(CrewProfessionType.Captain)
	
	if (not captains or captains == 0) then return false end
	
	return true
end
	
function initialize(help, sender, action, ...)
	local player = Player(sender)
	local selected
	local ship, shipIndex
	local retval
	local errorMessage
	
	shipIndex = player.craftIndex
	ship = Entity(shipIndex)
	
	selected = ship.selectedObject

	if (not selected)
	then
		haulGoodsCmdSendError(player, "Error: No ship selected.\n")
		return terminate()
	end
	
	if (action == "status")
	then
		retval, isHauler = selected:invokeFunction(haulscript, "isHaulGoodsHauler")

		if (retval > 0 or not isHauler)
		then
			haulGoodsCmdSendError(player, "Targeted ship (" .. selected.name .. ") is not a hauler.\n", help)
			return terminate()
		end

		local status
		retval, status = selected:invokeFunction(haulscript, "haulGoodsStatus")

		player:sendChatMessage("HaulGoods", 0, status)
	elseif (action == "start")
	then
		if (not haulGoodsCheckValidShip(player, selected))
		then
			haulGoodsCmdSendError(player, "That ship (" .. selected.name .. ") has no captain or does not belong to you.\n", help)
			return terminate()
		end
		
		-- Check if the ship is already a hauler
		retval, isHauler = selected:invokeFunction(haulscript, "isHaulGoodsHauler")
		if (retval == 0 and isHauler)
		then
			haulGoodsCmdSendError(player, "That ship (" .. selected.name .. ") is already hauling.\n", help)
			return terminate()
		end
		
		-- From craftorders, which doesn't take a ship argument
		-- Remove all outstanding AI orders
		local index, name
		for index, name in pairs(selected:getScripts())
		do
			if string.match(name, "data/scripts/entity/ai/")
			then
				selected:removeScript(index)
			end
        end
		
		-- Add the haulgoods order
		selected:addScript(haulscript)
	elseif (action == "stop")
	then
		if (not haulGoodsCheckValidShip(player, selected))
		then
			haulGoodsCmdSendError(player, "That ship (" .. selected.name .. ") has no captain or does not belong to you.\n", help)
			return terminate()
		end
		
		selected:removeScript(haulscript)
    end
		
	terminate()
end
