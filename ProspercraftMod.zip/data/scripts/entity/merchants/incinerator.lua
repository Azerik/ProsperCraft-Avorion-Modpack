package.path = package.path .. ";data/scripts/entity/merchants/?.lua;"
package.path = package.path .. ";data/scripts/lib/?.lua;"
require ("stringutility")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace Incinerator
Incinerator = require ("consumer")

Biotope.consumerName = "Incinerator"%_t
Biotope.consumerIcon = "data/textures/icons/pixel/scrapyard_fat.png"
Biotope.consumedGoods = {"Toxic Waste"}
