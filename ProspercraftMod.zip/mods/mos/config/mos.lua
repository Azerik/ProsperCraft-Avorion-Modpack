config = {}
config.VERSION = "[mOS][0.96] "

config.MONEY_PER_JUMP = 500000          --change to your needs
config.CALLDISTANCE = 1500              --15Km is 1.500 not 15.000. Who made this up ?
config.MAXDISPERSION = 4000             --  +-40km dispersion for asteroid reentry


return config
