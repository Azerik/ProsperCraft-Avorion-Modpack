config = {}
config.MONEY_PER_JUMP = 500000          --change to your needs
config.CALLDISTANCE = 1500              --10Km is 1.000 not 10.000. Who made this up ?
config.MAXDISPERSION = 4000             --  +-40km dispersion for asteroid rentry

return config
