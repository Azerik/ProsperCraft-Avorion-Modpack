package.path = package.path .. ";data/scripts/entity/merchants/?.lua;"
package.path = package.path .. ";data/scripts/lib/?.lua;"
require ("stringutility")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace FoodCourt
FoodCourt = require ("consumer")

FoodCourt.consumerName = "Mall Food Court"%_t
FoodCourt.consumerIcon = "data/textures/icons/pixel/trade.png"
FoodCourt.consumedGoods = {"Beer", "Wine", "Liquor", "Haggis", "Luxury Food", "Pizza", "Soylent Green", "Gluten Free Vegan Pizza", "Water", "Hamburger", "Spaghetti", "Taco", "Fish Taco", "Sushi", "Bacon Sandwich", "Mac n Cheese", "Neeps n Tatties", "Pulled Pork", "Noodle", "Fried Rice", "Cookie", "Cake", "Fish and Chips"}
