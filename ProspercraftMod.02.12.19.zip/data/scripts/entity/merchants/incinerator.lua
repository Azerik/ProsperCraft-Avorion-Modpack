package.path = package.path .. ";data/scripts/entity/merchants/?.lua;"
package.path = package.path .. ";data/scripts/lib/?.lua;"
require ("stringutility")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace Incinerator
Incinerator = require ("consumer")

Incinerator.consumerName = "Incinerator"%_t
Incinerator.consumerIcon = "data/textures/icons/pixel/scrapyard_fat.png"
Incinerator.consumedGoods = {"Toxic Waste", "Gluten Free Vegan Pizza"}
