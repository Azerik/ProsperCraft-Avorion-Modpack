-- Command script to control entity/ai/haulgoods.lua

package.path = package.path .. ";data/scripts/lib/?.lua"

require ("utility")

function execute(sender, commandName, action, ...)
	Player(sender):addScriptOnce("data/scripts/entity/ai/autotrade_cmd.lua", getHelp(), sender, action, ...)
	
    return 0, "", ""
end

function getDescription()
    return "Controls the actions for the entity/ai/autotrade.lua script on the targeted ship."
end

function getHelp()
    return getDescription() .. "\n/autotrade start\n/autotrade stop\n/autotrade status\n\nStart: Start the hauling script for the selected ship.\nStop: Stop the hauling script for the selected ship.\nStatus: Show the status of the hauling script for the selected ship."
end
