package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/server/?.lua"
require ("factions")
require ("stringutility")

function onStartUp()
    Server():registerCallback("onPlayerLogIn", "onPlayerLogIn")
    Server():registerCallback("onPlayerLogOff", "onPlayerLogOff")
    Galaxy():registerCallback("onPlayerCreated", "onPlayerCreated")
    Galaxy():registerCallback("onFactionCreated", "onFactionCreated")
end

function onShutDown()

end

function update(timeStep)
    local server = Server()

    local guardianRespawnTime = server:getValue("guardian_respawn_time")
    if guardianRespawnTime then

        guardianRespawnTime = guardianRespawnTime - timeStep;
        if guardianRespawnTime < 0 then
            guardianRespawnTime = nil
        end

        server:setValue("guardian_respawn_time", guardianRespawnTime)
    end

    local serverRuntime = server:getValue("online_time") or 0
    serverRuntime = serverRuntime + timeStep
    server:setValue("online_time", serverRuntime)

end

function onPlayerCreated(index)
    local player = Player(index)
    Server():broadcastChatMessage("Server", 0, "Player %s created!"%_t, player.name)
    
    -- welcome mail
    local mail = Mail()
    --mail.money = 100000
    mail.sender = "Prospercraft"
    mail.header = "Welcome"
    mail:setResources(100, 20, 0, 0, 0, 0, 0)
    mail.text = "Welcome to Prospercraft.  We are a Family Friendly PvE community, please keep your chat appropriate for all audiences at all times.  Detailed rules can be found at prospercraft.com/rules and pinned in the #Avorion chat channel on our discord.  Our Discord is linked on prospercraft.com.  You will be held to those rules even if you don't read them. Our modpack is pinned in our discord or at bit.ly/AvoProsperMod. Have fun stormin' the castle!"
    player:addMail(mail)
    
end

function onFactionCreated(index)

end

function onPlayerLogIn(playerIndex)
    local player = Player(playerIndex)
    Server():broadcastChatMessage("Server", 0, "Player %s joined the galaxy"%_t, player.name)

    player:addScriptOnce("headhunter.lua")
    player:addScriptOnce("eventscheduler.lua")
    player:addScriptOnce("story/spawnswoks.lua")
    player:addScriptOnce("story/spawnai.lua")
    player:addScriptOnce("story/spawnguardian.lua")
    player:addScriptOnce("story/spawnadventurer.lua")
    player:addScriptOnce("mods/mos/scripts/player/asteroidMover.lua")                                    --mOS
    matchResources(player)
end

function onPlayerLogOff(playerIndex)
    local player = Player(playerIndex)
    Server():broadcastChatMessage("Server", 0, "Player %s left the galaxy"%_t, player.name)

end
